This directory contains code that some may find useful. Code here is not an official
part of Dulwich, and may no longer work. Unlike the rest of Dulwich, it is not regularly
tested.
